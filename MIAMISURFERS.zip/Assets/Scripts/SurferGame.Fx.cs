using System.Collections.Generic;
using UnityEngine;

namespace MiniSurfers
{
    // Cheap pooled particles made from cubes, plus the player's blob shadow.
    public partial class SurferGame
    {
        class Particle
        {
            public Transform t;
            public Renderer rend;
            public Vector3 vel;
            public float life, max, size;
            public bool grav, streak, alive;
        }

        const int MaxParts = 110;
        readonly List<Particle> parts = new List<Particle>();
        Transform fxRoot, shadow;
        int partCursor;
        float dustT, streakT;

        void BuildFx()
        {
            fxRoot = new GameObject("Fx").transform;
            for (int i = 0; i < MaxParts; i++)
            {
                var g = PrimM(PrimitiveType.Cube, fxRoot, Vector3.zero, Vector3.one, GetMat(Color.white));
                g.SetActive(false);
                parts.Add(new Particle { t = g.transform, rend = g.GetComponent<Renderer>() });
            }
            shadow = Prim(PrimitiveType.Cylinder, null, new Vector3(0f, 0.03f, 0f), new Vector3(0.9f, 0.01f, 0.9f), new Color(0.08f, 0.08f, 0.12f)).transform;
            shadow.name = "PlayerShadow";
        }

        Particle NextPart()
        {
            for (int n = 0; n < MaxParts; n++)
            {
                partCursor = (partCursor + 1) % MaxParts;
                if (!parts[partCursor].alive) return parts[partCursor];
            }
            return parts[partCursor]; // pool full: recycle the oldest
        }

        void Emit(Vector3 pos, Vector3 vel, Color c, float size, float life, bool grav, bool streak)
        {
            var p = NextPart();
            p.alive = true;
            p.max = p.life = life;
            p.vel = vel;
            p.size = size;
            p.grav = grav;
            p.streak = streak;
            p.t.gameObject.SetActive(true);
            p.t.position = pos;
            p.t.rotation = streak ? Quaternion.identity : Random.rotation;
            p.t.localScale = streak ? new Vector3(size * 0.4f, size * 0.4f, size * 8f) : Vector3.one * size;
            p.rend.sharedMaterial = GetMat(c);
        }

        // Radial burst: coin sparkles, landing puffs, crash confetti.
        void Burst(Vector3 pos, Color c, int count, float spd, float size, float life)
        {
            for (int i = 0; i < count; i++)
            {
                var v = Random.onUnitSphere * spd;
                v.y = Mathf.Abs(v.y) + 2f;
                v.z -= speed * 0.3f;
                Emit(pos, v, c, size * Random.Range(0.7f, 1.3f), life * Random.Range(0.7f, 1.2f), true, false);
            }
        }

        void UpdateFx(float dt)
        {
            if (state == State.Playing)
            {
                // running dust (sparks while sliding)
                if (py <= 0.001f)
                {
                    dustT -= dt;
                    if (dustT <= 0f)
                    {
                        bool sliding = slideT > 0f;
                        dustT = sliding ? 0.03f : 0.07f;
                        var c = sliding ? new Color(1f, 0.8f, 0.4f) : new Color(0.95f, 0.85f, 0.65f);
                        Emit(new Vector3(px + Random.Range(-0.2f, 0.2f), 0.1f, -0.2f),
                            new Vector3(Random.Range(-0.8f, 0.8f), Random.Range(0.4f, 1.6f), -speed * 0.6f),
                            c, sliding ? 0.14f : 0.2f, 0.5f, true, false);
                    }
                }

                // wind streaks at high speed
                if (speed > 14f)
                {
                    streakT -= dt;
                    if (streakT <= 0f)
                    {
                        streakT = Mathf.Lerp(0.12f, 0.04f, Mathf.Clamp01((speed - 14f) / 16f));
                        float sx = (Random.value > 0.5f ? 1f : -1f) * Random.Range(3.5f, 9f);
                        Emit(new Vector3(sx, Random.Range(0.4f, 5f), 40f), new Vector3(0f, 0f, -speed * 2f),
                            Color.white, 0.12f, 1.1f, false, true);
                    }
                }
            }

            for (int i = 0; i < parts.Count; i++)
            {
                var p = parts[i];
                if (!p.alive) continue;
                p.life -= dt;
                if (p.life <= 0f)
                {
                    p.alive = false;
                    p.t.gameObject.SetActive(false);
                    continue;
                }
                if (p.grav) p.vel.y -= 14f * dt;
                var pos = p.t.position + p.vel * dt;
                if (p.grav && pos.y < 0.05f) { pos.y = 0.05f; p.vel.y *= -0.3f; }
                p.t.position = pos;
                float k = Mathf.Clamp01(p.life / p.max);
                if (p.streak) p.t.localScale = new Vector3(p.size * 0.4f, p.size * 0.4f, p.size * 8f * Mathf.Min(1f, k * 3f));
                else p.t.localScale = Vector3.one * (p.size * k);
            }

            // blob shadow shrinks as the player rises
            float s = 0.9f / (1f + py * 0.6f);
            shadow.position = new Vector3(px, 0.03f, 0f);
            shadow.localScale = new Vector3(s, 0.01f, s);
        }
    }
}
