using System.Collections.Generic;
using UnityEngine;

namespace MiniSurfers
{
    // Self-building endless runner. Everything (world, people, camera, UI) is created from code,
    // so it runs in any scene with zero setup. Works with old and new Input System (uses IMGUI events).
    //
    // The class is split over several files:
    //   SurferGame.cs            core loop, audio, input, obstacles, camera
    //   SurferGame.Characters.cs playable roster + human builder + player animation
    //   SurferGame.World.cs      street, beach crowd, day/night sky
    //   SurferGame.Fx.cs         particles + shadow
    //   SurferGame.Hud.cs        heads-up display + menus
    public partial class SurferGame : MonoBehaviour
    {
        enum State { Menu, Playing, Over }

        class Item { public Transform t; public int type; public Transform spin; public float phase; }

        const float LaneW = 2f;
        const float SegLen = 20f;
        const int SegCount = 8;
        const float SpawnZ = 70f;
        const float MagnetTime = 8f;
        // item types: 0 van, 1 low barrier, 2 high bar, 3 coin, 4 rolling beach ball, 5 magnet
        static readonly float[] HalfDepth = { 1.7f, 0.7f, 0.7f, 0.7f, 0.6f, 0.7f };

        State state = State.Menu;
        Transform world, player;
        Camera cam;
        Light sunLight;
        Vector3 camPos, camLook;
        readonly List<Segment> segments = new List<Segment>();
        readonly List<Item> items = new List<Item>();
        readonly Dictionary<Color, Material> mats = new Dictionary<Color, Material>();
        Shader baseShader;
        Material windowMat, lampMat, cloudMat, sunMat;

        int charIdx;
        int lane = 1;
        float px, py, vy, slideT;
        float speed = 5f, spawnTimer = 9999f;
        float score, flash, overT, dist, playT, shakeT, magnetT, invulnT, menuSpin;
        int coins, best, livesLeft;
        bool newBest;
        bool swiping;
        Vector2 swipeStart;
        GUIStyle style;

        static SurferGame instance;
        bool ready;

        // ---------- audio ----------
        // Clips are loaded from Assets/Resources/Sounds (jump, land, slide, lane, coin, crash, start, gameover, music)
        readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();
        AudioSource sfxSrc, musicSrc;
        bool muted;
        const float SfxVolume = 0.8f;
        const float MusicVolume = 0.35f;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Boot()
        {
            if (instance != null) return;
            new GameObject("MiniSurfersGame").AddComponent<SurferGame>();
        }

        void OnDestroy()
        {
            if (instance == this) instance = null;
        }

        void Awake()
        {
            if (instance != null && instance != this) { Destroy(gameObject); return; }
            instance = this;
            ready = true;
            best = PlayerPrefs.GetInt("MiniSurfersBest", 0);
            charIdx = Mathf.Clamp(PlayerPrefs.GetInt("MiniSurfersChar", 0), 0, Chars.Length - 1);
            SetupAudio();
            SetupCamera();
            SetupLight();
            BuildMaterials();
            BuildWorld();
            BuildSky();
            BuildFx();
            BuildPlayer();
            ResetRun(false);
        }

        // ---------- audio ----------
        void SetupAudio()
        {
            string[] names = { "jump", "land", "slide", "lane", "coin", "crash", "start", "gameover", "music" };
            foreach (var n in names)
            {
                var c = Resources.Load<AudioClip>("Sounds/" + n);
                if (c == null) Debug.LogWarning("MiniSurfers: missing sound Resources/Sounds/" + n);
                clips[n] = c;
            }
            sfxSrc = gameObject.AddComponent<AudioSource>();
            sfxSrc.playOnAwake = false;
            sfxSrc.spatialBlend = 0f;
            musicSrc = gameObject.AddComponent<AudioSource>();
            musicSrc.playOnAwake = false;
            musicSrc.loop = true;
            musicSrc.spatialBlend = 0f;
            musicSrc.volume = MusicVolume;
            muted = PlayerPrefs.GetInt("MiniSurfersMuted", 0) == 1;
            AudioListener.pause = false;
        }

        void Sfx(string name, float vol = 1f, float pitch = 1f)
        {
            if (muted) return;
            AudioClip c;
            if (!clips.TryGetValue(name, out c) || c == null) return;
            sfxSrc.pitch = pitch;
            sfxSrc.PlayOneShot(c, vol * SfxVolume);
        }

        void PlayMusic()
        {
            AudioClip c;
            if (!clips.TryGetValue("music", out c) || c == null) return;
            if (musicSrc.clip != c) musicSrc.clip = c;
            musicSrc.volume = muted ? 0f : MusicVolume;
            if (!musicSrc.isPlaying) musicSrc.Play();
        }

        void StopMusic()
        {
            if (musicSrc != null) musicSrc.Stop();
        }

        void ToggleMute()
        {
            muted = !muted;
            PlayerPrefs.SetInt("MiniSurfersMuted", muted ? 1 : 0);
            if (musicSrc != null) musicSrc.volume = muted ? 0f : MusicVolume;
        }

        // ---------- setup ----------
        void SetupCamera()
        {
            cam = Camera.main;
            if (cam == null)
            {
                var go = new GameObject("Main Camera");
                go.tag = "MainCamera";
                cam = go.AddComponent<Camera>();
                go.AddComponent<AudioListener>();
            }
            var sky = new Color(1f, 0.66f, 0.58f);
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = sky;
            cam.farClipPlane = 240f;
            cam.fieldOfView = 48f;
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = sky;
            RenderSettings.fogStartDistance = 60f;
            RenderSettings.fogEndDistance = 190f;
            // start close to the runner for the select screen
            camPos = new Vector3(0f, 1.7f, -4.2f);
            camLook = new Vector3(0f, 1f, 0f);
            cam.transform.position = camPos;
            cam.transform.LookAt(camLook);
        }

        void SetupLight()
        {
            var go = new GameObject("MiniSurfers Light");
            sunLight = go.AddComponent<Light>();
            sunLight.type = LightType.Directional;
            sunLight.intensity = 0.9f;
            sunLight.color = new Color(1f, 0.85f, 0.72f);
            go.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.72f, 0.62f, 0.68f);
        }

        // ---------- primitive + material helpers ----------
        void EnsureShader()
        {
            if (baseShader != null) return;
            var tmp = GameObject.CreatePrimitive(PrimitiveType.Cube);
            baseShader = tmp.GetComponent<Renderer>().sharedMaterial.shader;
            Destroy(tmp);
        }

        void SetMatColor(Material m, Color c)
        {
            m.color = c;
            if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
        }

        // a fresh, uncached material whose colour we can animate (windows, lamps, clouds, sun)
        Material NewMat(Color c)
        {
            EnsureShader();
            var m = new Material(baseShader);
            SetMatColor(m, c);
            return m;
        }

        Material GetMat(Color c)
        {
            Material m;
            if (mats.TryGetValue(c, out m)) return m;
            m = NewMat(c);
            mats[c] = m;
            return m;
        }

        GameObject PrimM(PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, Material m)
        {
            var g = GameObject.CreatePrimitive(type);
            var col = g.GetComponent<Collider>();
            if (col != null) Destroy(col);
            g.transform.SetParent(parent, false);
            g.transform.localPosition = pos;
            g.transform.localScale = scale;
            g.GetComponent<Renderer>().sharedMaterial = m;
            return g;
        }

        GameObject Prim(PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, Color c)
        {
            return PrimM(type, parent, pos, scale, GetMat(c));
        }

        Transform Pivot(Transform parent, Vector3 pos)
        {
            var g = new GameObject("Pivot").transform;
            g.SetParent(parent, false);
            g.localPosition = pos;
            return g;
        }

        // ---------- run control ----------
        void ResetRun(bool start)
        {
            foreach (var it in items) if (it.t != null) Destroy(it.t.gameObject);
            items.Clear();
            var C = Chars[charIdx];
            lane = 1; px = 0f; py = 0f; vy = 0f; slideT = 0f;
            speed = start ? 10f : 5f;
            spawnTimer = start ? 25f : 9999f;
            score = 0f; coins = 0; flash = 0f;
            magnetT = 0f; invulnT = 0f; shakeT = 0f;
            livesLeft = C.extraLives;
            newBest = false;
            player.localScale = Vector3.one;
            player.position = new Vector3(0f, 0.9f, 0f);
        }

        void StartRun()
        {
            if (state == State.Over && overT < 0.5f) return;
            ResetRun(true);
            state = State.Playing;
            playT = 0f;
            Sfx("start");
            PlayMusic();
        }

        void Die()
        {
            state = State.Over;
            overT = 0f;
            flash = 1f;
            shakeT = 0.5f;
            StopMusic();
            Sfx("crash");
            Sfx("gameover", 0.8f);
            var at = player.position + new Vector3(0f, 0.5f, 0f);
            Burst(at, new Color(1f, 0.3f, 0.7f), 10, 5f, 0.22f, 1.1f);
            Burst(at, new Color(0.3f, 1f, 1f), 10, 5f, 0.22f, 1.1f);
            Burst(at, new Color(1f, 0.9f, 0.2f), 10, 5f, 0.22f, 1.1f);
            int s = Mathf.FloorToInt(score);
            if (s > best)
            {
                best = s;
                newBest = true;
                PlayerPrefs.SetInt("MiniSurfersBest", best);
                PlayerPrefs.Save();
            }
        }

        void ChangeChar(int dir)
        {
            SelectChar((charIdx + dir + Chars.Length) % Chars.Length);
        }

        void SelectChar(int idx)
        {
            if (state == State.Playing) return;
            if (idx < 0 || idx >= Chars.Length) return;
            charIdx = idx;
            PlayerPrefs.SetInt("MiniSurfersChar", charIdx);
            BuildPlayer();
            Sfx("lane", 0.8f, 1.2f);
            Burst(player.position + new Vector3(0f, 0.3f, 0f), Chars[charIdx].accent, 12, 3.5f, 0.16f, 0.8f);
            if (state == State.Menu) livesLeft = Chars[charIdx].extraLives;
        }

        void Move(int dir)
        {
            if (state != State.Playing) return;
            int nl = Mathf.Clamp(lane + dir, 0, 2);
            if (nl != lane) Sfx("lane", 0.7f, Random.Range(0.95f, 1.1f));
            lane = nl;
        }

        void Jump()
        {
            if (state != State.Playing) return;
            if (py <= 0.001f && vy <= 0f) { vy = Chars[charIdx].jumpV; slideT = 0f; Sfx("jump"); }
        }

        void Slide()
        {
            if (state != State.Playing) return;
            if (py > 0.001f) vy = -22f;
            if (slideT <= 0f) Sfx("slide", 0.8f);
            slideT = 0.7f;
        }

        // ---------- per-frame ----------
        void Update()
        {
            if (!ready) return;
            float dt = Mathf.Min(Time.deltaTime, 0.05f);
            var C = Chars[charIdx];
            if (flash > 0f) flash = Mathf.Max(0f, flash - dt * 1.5f);
            if (shakeT > 0f) shakeT = Mathf.Max(0f, shakeT - dt);
            if (bannerT > 0f) bannerT -= dt;
            playT += dt;

            if (state == State.Playing)
            {
                speed = Mathf.Min(speed + C.accel * dt, 30f);
                score += speed * dt;
                if (magnetT > 0f) magnetT -= dt;
                if (invulnT > 0f) invulnT -= dt;
            }
            else if (state == State.Menu) speed = 5f;
            else { speed = Mathf.MoveTowards(speed, 0f, 25f * dt); overT += dt; }
            dist += speed * dt;

            ScrollWorld(dt);
            UpdateWorldLife(dt);
            UpdateSky(dt);

            if (state == State.Playing)
            {
                UpdatePlayer(dt);
                UpdateItems(dt);
                Spawn(dt);
            }
            AnimatePlayer(dt);
            UpdateFx(dt);
            UpdateCamera(dt);
        }

        void UpdatePlayer(float dt)
        {
            var C = Chars[charIdx];
            float tx = (lane - 1) * LaneW;
            px = Mathf.MoveTowards(px, tx, C.laneSpeed * dt);
            if (py > 0f || vy > 0f)
            {
                vy -= 32f * dt;
                py += vy * dt;
                if (py <= 0f)
                {
                    py = 0f; vy = 0f;
                    Sfx("land", 0.7f);
                    Burst(new Vector3(px, 0.1f, 0f), new Color(0.95f, 0.85f, 0.65f), 5, 1.6f, 0.2f, 0.45f);
                }
            }
            if (slideT > 0f) slideT -= dt;
            float s = slideT > 0f ? 0.45f : 1f;
            player.localScale = new Vector3(1f, s, 1f);
            player.position = new Vector3(px, 0.9f * s + py, 0f);
        }

        void UpdateItems(float dt)
        {
            var C = Chars[charIdx];
            for (int i = items.Count - 1; i >= 0; i--)
            {
                var it = items[i];
                var p = it.t.position;
                p.z -= (it.type == 4 ? speed + 5f : speed) * dt;

                // magnet pulls nearby coins toward the runner
                if (it.type == 3 && magnetT > 0f && p.z < 10f && p.z > -1f)
                    p.x = Mathf.MoveTowards(p.x, px, 16f * dt);

                it.t.position = p;
                if (it.type == 3 || it.type == 5) it.t.Rotate(0f, 240f * dt, 0f, Space.World);
                if (it.type == 4 && it.spin != null) it.spin.Rotate(-420f * dt, 0f, 0f, Space.Self);

                if (Mathf.Abs(p.z) < HalfDepth[it.type] && Mathf.Abs(p.x - px) < 0.9f)
                {
                    bool hit = false;
                    switch (it.type)
                    {
                        case 0: hit = true; break;
                        case 1: hit = py < 0.75f; break;
                        case 2: hit = !(slideT > 0f && py < 0.2f) && py < 1.6f; break;
                        case 4: hit = true; break;
                        case 3:
                            coins++;
                            score += C.coinBonus;
                            Sfx("coin", 0.8f, Mathf.Min(1f + (coins % 8) * 0.04f, 1.3f));
                            Burst(new Vector3(p.x, 1.0f, 0f), Gold, 5, 3f, 0.14f, 0.5f);
                            Destroy(it.t.gameObject);
                            items.RemoveAt(i);
                            continue;
                        case 5:
                            magnetT = MagnetTime;
                            Sfx("coin", 1f, 1.5f);
                            Burst(new Vector3(p.x, 1.0f, 0f), Cyan, 12, 4f, 0.18f, 0.7f);
                            Destroy(it.t.gameObject);
                            items.RemoveAt(i);
                            continue;
                    }
                    if (hit && invulnT <= 0f)
                    {
                        if (livesLeft > 0)
                        {
                            // extra life: smash through and flicker for a moment
                            livesLeft--;
                            invulnT = 1.6f;
                            flash = 0.6f;
                            shakeT = 0.3f;
                            Sfx("crash", 0.6f);
                            Burst(new Vector3(p.x, 1.0f, 0f), new Color(1f, 0.5f, 0.3f), 14, 5f, 0.22f, 0.9f);
                            Destroy(it.t.gameObject);
                            items.RemoveAt(i);
                            continue;
                        }
                        Die();
                        return;
                    }
                }

                if (p.z < -6f)
                {
                    Destroy(it.t.gameObject);
                    items.RemoveAt(i);
                }
            }
        }

        void Spawn(float dt)
        {
            spawnTimer -= speed * dt;
            if (spawnTimer > 0f) return;
            SpawnRow();
            spawnTimer = Random.Range(9f, 15f) - Mathf.Min(speed * 0.1f, 3f);
        }

        void SpawnRow()
        {
            int pattern = Random.Range(0, 8);
            int free = Random.Range(0, 3);
            switch (pattern)
            {
                case 0:
                    for (int l = 0; l < 3; l++)
                    {
                        if (l == free) CoinLine(l, SpawnZ); else AddItem(0, l, SpawnZ);
                    }
                    break;
                case 1:
                    for (int l = 0; l < 3; l++) AddItem(1, l, SpawnZ);
                    break;
                case 2:
                    for (int l = 0; l < 3; l++) AddItem(2, l, SpawnZ);
                    break;
                case 3:
                    int bl = Random.Range(0, 3);
                    AddItem(0, bl, SpawnZ);
                    CoinLine((bl + 1) % 3, SpawnZ);
                    break;
                case 4:
                    CoinLine(Random.Range(0, 3), SpawnZ);
                    break;
                case 5:
                    // magnet pickup (or a coin line if one is already active)
                    if (magnetT > 0f) { CoinLine(Random.Range(0, 3), SpawnZ); break; }
                    int ml = Random.Range(0, 3);
                    AddItem(5, ml, SpawnZ);
                    CoinLine((ml + 1) % 3, SpawnZ);
                    break;
                case 6:
                    // two rolling beach balls, one free lane with coins
                    for (int l = 0; l < 3; l++)
                    {
                        if (l == free) CoinLine(l, SpawnZ); else AddItem(4, l, SpawnZ + Random.Range(0f, 4f));
                    }
                    break;
                default:
                    int jl = Random.Range(0, 3);
                    AddItem(4, jl, SpawnZ);
                    CoinLine((jl + 1 + Random.Range(0, 2)) % 3, SpawnZ);
                    break;
            }
        }

        void CoinLine(int l, float z)
        {
            for (int i = 0; i < 6; i++) AddItem(3, l, z + i * 2f);
        }

        void AddItem(int type, int l, float z)
        {
            var go = new GameObject("Item" + type);
            go.transform.SetParent(world, false);
            go.transform.position = new Vector3((l - 1) * LaneW, 0f, z);
            var t = go.transform;
            Transform spinner = null;
            switch (type)
            {
                case 0:
                    Prim(PrimitiveType.Cube, t, new Vector3(0f, 1.1f, 0f), new Vector3(1.7f, 2.2f, 3f), new Color(0.85f, 0.15f, 0.15f));
                    Prim(PrimitiveType.Cube, t, new Vector3(0f, 1.6f, -1.52f), new Vector3(1.2f, 0.5f, 0.05f), new Color(1f, 0.9f, 0.4f));
                    break;
                case 1:
                    Prim(PrimitiveType.Cube, t, new Vector3(0f, 0.4f, 0f), new Vector3(1.8f, 0.8f, 0.5f), new Color(1f, 0.6f, 0.1f));
                    break;
                case 2:
                    Prim(PrimitiveType.Cube, t, new Vector3(0f, 1.35f, 0f), new Vector3(1.9f, 0.5f, 0.5f), new Color(0.9f, 0.2f, 0.75f));
                    Prim(PrimitiveType.Cube, t, new Vector3(-0.9f, 0.7f, 0f), new Vector3(0.12f, 1.4f, 0.12f), new Color(0.3f, 0.3f, 0.3f));
                    Prim(PrimitiveType.Cube, t, new Vector3(0.9f, 0.7f, 0f), new Vector3(0.12f, 1.4f, 0.12f), new Color(0.3f, 0.3f, 0.3f));
                    break;
                case 4:
                {
                    // a big beach ball rolling fast toward the player
                    var ball = Pivot(t, new Vector3(0f, 0.8f, 0f));
                    spinner = ball;
                    Prim(PrimitiveType.Sphere, ball, Vector3.zero, new Vector3(1.6f, 1.6f, 1.6f), new Color(1f, 0.35f, 0.6f));
                    Prim(PrimitiveType.Cube, ball, Vector3.zero, new Vector3(1.62f, 0.3f, 0.3f), Color.white);
                    Prim(PrimitiveType.Cube, ball, Vector3.zero, new Vector3(0.3f, 1.62f, 0.3f), new Color(1f, 0.9f, 0.2f));
                    Prim(PrimitiveType.Cube, ball, Vector3.zero, new Vector3(0.3f, 0.3f, 1.62f), new Color(0.3f, 0.9f, 1f));
                    break;
                }
                case 5:
                {
                    // horseshoe magnet
                    t.position += new Vector3(0f, 0.9f, 0f);
                    var red = new Color(0.9f, 0.15f, 0.2f);
                    Prim(PrimitiveType.Cube, t, new Vector3(0f, 0.3f, 0f), new Vector3(0.8f, 0.2f, 0.25f), red);
                    Prim(PrimitiveType.Cube, t, new Vector3(-0.3f, 0f, 0f), new Vector3(0.2f, 0.6f, 0.25f), red);
                    Prim(PrimitiveType.Cube, t, new Vector3(0.3f, 0f, 0f), new Vector3(0.2f, 0.6f, 0.25f), red);
                    Prim(PrimitiveType.Cube, t, new Vector3(-0.3f, -0.36f, 0f), new Vector3(0.2f, 0.16f, 0.25f), Color.white);
                    Prim(PrimitiveType.Cube, t, new Vector3(0.3f, -0.36f, 0f), new Vector3(0.2f, 0.16f, 0.25f), Color.white);
                    break;
                }
                default:
                    t.position += new Vector3(0f, 0.9f, 0f);
                    var coin = Prim(PrimitiveType.Cylinder, t, Vector3.zero, new Vector3(0.55f, 0.05f, 0.55f), new Color(1f, 0.85f, 0.1f));
                    coin.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
                    break;
            }
            items.Add(new Item { t = t, type = type, spin = spinner });
        }

        void UpdateCamera(float dt)
        {
            Vector3 tp, tl;
            float k, fov;
            if (state == State.Menu)
            {
                // close-up showcase of the selected runner
                tp = new Vector3(0f, 1.7f, -4.2f);
                tl = new Vector3(0f, 1f, 0f);
                k = 4f;
                fov = 48f;
            }
            else
            {
                tp = new Vector3(px * 0.6f, 4.4f, -7f);
                tl = new Vector3(px * 0.3f, 1.2f, 8f);
                k = playT < 1f ? 5f : 10f;
                // widen the view as speed picks up
                fov = 60f + Mathf.Clamp((speed - 10f) * 0.35f, 0f, 8f);
            }
            camPos = Vector3.Lerp(camPos, tp, k * dt);
            camLook = Vector3.Lerp(camLook, tl, k * dt);
            cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, fov, 4f * dt);
            Vector3 shake = shakeT > 0f ? Random.insideUnitSphere * shakeT * 0.5f : Vector3.zero;
            cam.transform.position = camPos + shake;
            cam.transform.LookAt(camLook);
        }

        // ---------- input + UI (IMGUI works with any Input System setting) ----------
        void OnGUI()
        {
            if (!ready) return;
            var e = Event.current;
            HandleInput(e);
            if (e.type == EventType.Repaint) DrawHud();
        }

        void HandleInput(Event e)
        {
            if (e.type == EventType.KeyDown)
            {
                switch (e.keyCode)
                {
                    case KeyCode.LeftArrow: case KeyCode.A:
                        if (state == State.Playing) Move(-1); else if (state == State.Menu || overT > 0.6f) ChangeChar(-1);
                        break;
                    case KeyCode.RightArrow: case KeyCode.D:
                        if (state == State.Playing) Move(1); else if (state == State.Menu || overT > 0.6f) ChangeChar(1);
                        break;
                    case KeyCode.UpArrow: case KeyCode.W: Jump(); break;
                    case KeyCode.DownArrow: case KeyCode.S: Slide(); break;
                    case KeyCode.Space:
                        if (state != State.Playing) StartRun(); else Jump();
                        break;
                    case KeyCode.M: ToggleMute(); break;
                    case KeyCode.Return:
                        if (state != State.Playing) StartRun();
                        break;
                    default:
                        // number keys 1-6 pick a runner
                        int n = (int)e.keyCode - (int)KeyCode.Alpha1;
                        if (n >= 0 && n < Chars.Length && (state == State.Menu || overT > 0.6f)) SelectChar(n);
                        break;
                }
            }
            else if (e.type == EventType.MouseDown)
            {
                if (state != State.Playing && TryMenuClick(e.mousePosition))
                {
                    swiping = false;
                    e.Use();
                    return;
                }
                swiping = true;
                swipeStart = e.mousePosition;
            }
            else if (e.type == EventType.MouseDrag && swiping)
            {
                var d = e.mousePosition - swipeStart;
                if (d.magnitude > 45f)
                {
                    swiping = false;
                    if (state != State.Playing)
                    {
                        // swipe sideways on the menu to browse runners
                        if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) ChangeChar(d.x > 0f ? -1 : 1);
                    }
                    else if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) Move(d.x > 0f ? 1 : -1);
                    else if (d.y < 0f) Jump();
                    else Slide();
                }
            }
            else if (e.type == EventType.MouseUp)
            {
                if (swiping && state != State.Playing) StartRun();
                swiping = false;
            }
        }
    }
}
