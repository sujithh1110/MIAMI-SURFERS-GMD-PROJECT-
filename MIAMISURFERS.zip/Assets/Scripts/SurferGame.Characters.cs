using UnityEngine;

namespace MiniSurfers
{
    // Everything to do with people: the playable roster, the procedural human builder,
    // random beach-goer variants and the player's animation.
    public partial class SurferGame
    {
        // A posable little person. Local space: feet at y = -0.9, head top at about +0.95, facing +Z.
        class Rig { public Transform body, head, legL, legR, armL, armR; }

        class CharDef
        {
            public string name, perk;
            public Color skin, hair, shirt, shorts, legs, shoe, accent;
            // 0 = cap, 1 = ponytail, 2 = afro + headband, 3 = bob + sunhat, 4 = captain, 5 = bun + visor
            public int hairStyle;
            public bool shades, skirt, sleeves, pattern;
            public float bulk = 1f;
            // gameplay perks
            public float jumpV = 12f, laneSpeed = 16f, accel = 0.2f;
            public int coinBonus, extraLives;
            public CharDef Clone() { return (CharDef)MemberwiseClone(); }
        }

        static Color Hex(int h)
        {
            return new Color(((h >> 16) & 255) / 255f, ((h >> 8) & 255) / 255f, (h & 255) / 255f);
        }

        // ---------- the roster ----------
        static readonly CharDef[] Chars =
        {
            new CharDef
            {
                name = "KAI", perk = "Balanced all-rounder",
                skin = Hex(0xF5C294), hair = Hex(0x3B2A1A), shirt = Hex(0xFF4D99), shorts = Hex(0x33BFF2),
                legs = Hex(0xF5C294), shoe = Color.white, accent = Hex(0xFFE640),
                hairStyle = 0, shades = true
            },
            new CharDef
            {
                name = "LUNA", perk = "Jumps higher",
                skin = Hex(0xD9A074), hair = Hex(0x5A3420), shirt = Hex(0x1ED6B8), shorts = Hex(0xFFF3E0),
                legs = Hex(0xD9A074), shoe = Hex(0xFF7AAE), accent = Hex(0xFF5FA2),
                hairStyle = 1, jumpV = 13.8f
            },
            new CharDef
            {
                name = "RICO", perk = "Lightning lane swaps",
                skin = Hex(0x7A4B2E), hair = Hex(0x15110F), shirt = Hex(0xFFD23F), shorts = Hex(0x2A6FDB),
                legs = Hex(0x7A4B2E), shoe = Hex(0x222233), accent = Hex(0xFF3B3B),
                hairStyle = 2, shades = true, bulk = 1.1f, laneSpeed = 26f
            },
            new CharDef
            {
                name = "MIKA", perk = "Coins give +5 bonus points",
                skin = Hex(0xF7D2B5), hair = Hex(0x111111), shirt = Hex(0xFF8A65), shorts = Hex(0xFF8A65),
                legs = Hex(0xF7D2B5), shoe = Color.white, accent = Hex(0xE8C26A),
                hairStyle = 3, skirt = true, coinBonus = 5
            },
            new CharDef
            {
                name = "CAPTAIN SAL", perk = "Tough: survives one crash",
                skin = Hex(0xE9B999), hair = Hex(0xF2F2F2), shirt = Hex(0xE63946), shorts = Hex(0xC8B27A),
                legs = Hex(0xC8B27A), shoe = Hex(0x6B4A2B), accent = Hex(0x1B2A49),
                hairStyle = 4, sleeves = true, pattern = true, bulk = 1.15f, extraLives = 1
            },
            new CharDef
            {
                name = "ZARA", perk = "Gentle speed ramp-up",
                skin = Hex(0x8D5A3B), hair = Hex(0x0D0D0D), shirt = Hex(0xA64DFF), shorts = Hex(0x5B2BC0),
                legs = Hex(0x5B2BC0), shoe = Hex(0x2EF2C4), accent = Hex(0xFF4DC4),
                hairStyle = 5, accel = 0.13f
            }
        };

        static readonly int[] ShirtPal = { 0xFF6F91, 0x2ED1C0, 0xFFC94A, 0x7B8CFF, 0xFF8A5B, 0x8BE04E, 0xE85DFF, 0xFFFFFF };
        static readonly int[] BottomPal = { 0x33BFF2, 0xF2F2F2, 0x2A2A40, 0xFFB84D, 0x3DDC97, 0xFF5F7A };
        static readonly int[] SkinPal = { 0xF5C294, 0xD9A074, 0x8D5A3B, 0x5C3A24, 0xF7D2B5, 0xC68642 };
        static readonly int[] HairPal = { 0x111111, 0x3B2A1A, 0x6B3F1D, 0xC9A24B, 0xB5382A, 0xEFEFEF };

        // A random beach-goer: one of the roster looks with shuffled colours.
        CharDef NpcVariant()
        {
            var d = Chars[Random.Range(0, Chars.Length)].Clone();
            d.skin = Hex(SkinPal[Random.Range(0, SkinPal.Length)]);
            d.hair = d.hairStyle == 4 ? Color.white : Hex(HairPal[Random.Range(0, HairPal.Length)]);
            d.shirt = Hex(ShirtPal[Random.Range(0, ShirtPal.Length)]);
            d.shorts = Hex(BottomPal[Random.Range(0, BottomPal.Length)]);
            d.legs = d.skin;
            d.accent = Hex(ShirtPal[Random.Range(0, ShirtPal.Length)]);
            d.pattern = false;
            d.sleeves = false;
            d.extraLives = 0;
            return d;
        }

        // ---------- human builder ----------
        Rig BuildHuman(Transform parent, CharDef d)
        {
            var r = new Rig();
            var cube = PrimitiveType.Cube;
            var sph = PrimitiveType.Sphere;
            var cyl = PrimitiveType.Cylinder;
            var dark = new Color(0.08f, 0.08f, 0.12f);
            float w = d.bulk;

            var b = Pivot(parent, Vector3.zero);
            r.body = b;

            // torso + shorts / skirt
            Prim(cube, b, new Vector3(0f, 0.25f, 0f), new Vector3(0.62f * w, 0.62f, 0.36f * w), d.shirt);
            Prim(cube, b, new Vector3(0f, -0.08f, 0f), new Vector3(0.64f * w, 0.26f, 0.38f * w), d.shorts);
            if (d.skirt) Prim(cyl, b, new Vector3(0f, -0.17f, 0f), new Vector3(0.88f, 0.1f, 0.68f), d.shorts);
            if (d.pattern)
            {
                // Hawaiian shirt flowers
                Prim(sph, b, new Vector3(-0.15f, 0.38f, 0.19f * w), new Vector3(0.11f, 0.11f, 0.03f), Color.white);
                Prim(sph, b, new Vector3(0.14f, 0.24f, 0.19f * w), new Vector3(0.1f, 0.1f, 0.03f), new Color(1f, 0.85f, 0.2f));
                Prim(sph, b, new Vector3(-0.08f, 0.08f, 0.19f * w), new Vector3(0.09f, 0.09f, 0.03f), Color.white);
                Prim(sph, b, new Vector3(0.16f, 0.46f, 0.19f * w), new Vector3(0.08f, 0.08f, 0.03f), Color.white);
            }
            else
            {
                Prim(cube, b, new Vector3(0f, 0.5f, 0.19f * w), new Vector3(0.3f, 0.06f, 0.02f), Color.Lerp(d.shirt, Color.white, 0.8f));
            }

            // head
            var h = Pivot(b, new Vector3(0f, 0.76f, 0f));
            r.head = h;
            Prim(sph, h, Vector3.zero, new Vector3(0.42f, 0.42f, 0.42f), d.skin);
            if (d.shades)
            {
                Prim(cube, h, new Vector3(0f, 0.03f, 0.2f), new Vector3(0.36f, 0.09f, 0.05f), dark);
            }
            else
            {
                Prim(sph, h, new Vector3(-0.085f, 0.03f, 0.185f), new Vector3(0.06f, 0.07f, 0.06f), dark);
                Prim(sph, h, new Vector3(0.085f, 0.03f, 0.185f), new Vector3(0.06f, 0.07f, 0.06f), dark);
                Prim(cube, h, new Vector3(0f, -0.08f, 0.2f), new Vector3(0.1f, 0.02f, 0.03f), new Color(0.75f, 0.3f, 0.3f));
            }

            switch (d.hairStyle)
            {
                case 0: // beach cap
                    Prim(sph, h, new Vector3(0f, 0.09f, -0.02f), new Vector3(0.44f, 0.3f, 0.44f), d.accent);
                    Prim(cyl, h, new Vector3(0f, 0.17f, 0f), new Vector3(0.44f, 0.04f, 0.44f), d.accent);
                    Prim(cube, h, new Vector3(0f, 0.15f, 0.27f), new Vector3(0.4f, 0.04f, 0.22f), d.accent);
                    Prim(sph, h, new Vector3(0f, -0.02f, -0.15f), new Vector3(0.3f, 0.25f, 0.2f), d.hair);
                    break;
                case 1: // ponytail
                    Prim(sph, h, new Vector3(0f, 0.06f, -0.05f), new Vector3(0.45f, 0.4f, 0.45f), d.hair);
                    Prim(sph, h, new Vector3(0f, 0.08f, -0.25f), new Vector3(0.16f, 0.16f, 0.16f), d.hair);
                    var tail = Prim(cyl, h, new Vector3(0f, -0.12f, -0.3f), new Vector3(0.09f, 0.18f, 0.09f), d.hair);
                    tail.transform.localRotation = Quaternion.Euler(-20f, 0f, 0f);
                    Prim(sph, h, new Vector3(0f, 0.09f, -0.2f), new Vector3(0.1f, 0.1f, 0.1f), d.accent);
                    break;
                case 2: // afro + headband
                    Prim(sph, h, new Vector3(0f, 0.14f, -0.1f), new Vector3(0.62f, 0.6f, 0.62f), d.hair);
                    Prim(cyl, h, new Vector3(0f, 0.08f, 0f), new Vector3(0.44f, 0.03f, 0.44f), d.accent);
                    break;
                case 3: // bob + straw sunhat
                    Prim(sph, h, new Vector3(0f, 0.02f, -0.05f), new Vector3(0.47f, 0.42f, 0.47f), d.hair);
                    Prim(cube, h, new Vector3(0f, 0.11f, 0.17f), new Vector3(0.32f, 0.06f, 0.07f), d.hair);
                    Prim(cyl, h, new Vector3(0f, 0.17f, 0f), new Vector3(0.86f, 0.02f, 0.86f), d.accent);
                    Prim(cyl, h, new Vector3(0f, 0.22f, 0f), new Vector3(0.46f, 0.06f, 0.46f), d.accent);
                    Prim(cyl, h, new Vector3(0f, 0.2f, 0f), new Vector3(0.48f, 0.02f, 0.48f), d.shirt);
                    break;
                case 4: // captain: white hair, beard, mustache, hat
                    Prim(sph, h, new Vector3(0f, 0f, -0.05f), new Vector3(0.46f, 0.4f, 0.46f), d.hair);
                    Prim(sph, h, new Vector3(0f, -0.13f, 0.1f), new Vector3(0.3f, 0.26f, 0.22f), d.hair);
                    Prim(cube, h, new Vector3(0f, -0.045f, 0.205f), new Vector3(0.2f, 0.04f, 0.05f), d.hair);
                    Prim(cyl, h, new Vector3(0f, 0.19f, 0f), new Vector3(0.48f, 0.07f, 0.48f), Color.white);
                    Prim(cyl, h, new Vector3(0f, 0.15f, 0f), new Vector3(0.5f, 0.02f, 0.5f), d.accent);
                    Prim(cube, h, new Vector3(0f, 0.15f, 0.2f), new Vector3(0.4f, 0.03f, 0.24f), d.accent);
                    Prim(sph, h, new Vector3(0f, 0.2f, 0.245f), new Vector3(0.08f, 0.08f, 0.03f), new Color(1f, 0.85f, 0.2f));
                    break;
                case 5: // bun + sports visor
                    Prim(sph, h, new Vector3(0f, 0.06f, -0.05f), new Vector3(0.45f, 0.4f, 0.45f), d.hair);
                    Prim(sph, h, new Vector3(0f, 0.27f, -0.07f), new Vector3(0.2f, 0.2f, 0.2f), d.hair);
                    Prim(cyl, h, new Vector3(0f, 0.1f, 0f), new Vector3(0.45f, 0.03f, 0.45f), d.accent);
                    Prim(cube, h, new Vector3(0f, 0.1f, 0.25f), new Vector3(0.38f, 0.03f, 0.22f), d.accent);
                    break;
            }

            // legs (pivot at hip)
            r.legL = Pivot(b, new Vector3(-0.16f * w, -0.1f, 0f));
            r.legR = Pivot(b, new Vector3(0.16f * w, -0.1f, 0f));
            foreach (var leg in new[] { r.legL, r.legR })
            {
                Prim(cube, leg, new Vector3(0f, -0.38f, 0f), new Vector3(0.22f, 0.6f, 0.22f), d.legs);
                Prim(cube, leg, new Vector3(0f, -0.76f, 0.05f), new Vector3(0.26f, 0.12f, 0.38f), d.shoe);
            }

            // arms (pivot at shoulder)
            r.armL = Pivot(b, new Vector3(-0.4f * w, 0.5f, 0f));
            r.armR = Pivot(b, new Vector3(0.4f * w, 0.5f, 0f));
            foreach (var arm in new[] { r.armL, r.armR })
            {
                Prim(cube, arm, new Vector3(0f, -0.26f, 0f), new Vector3(0.15f, 0.52f, 0.15f), d.skin);
                Prim(sph, arm, new Vector3(0f, -0.55f, 0f), new Vector3(0.17f, 0.17f, 0.17f), d.skin);
                if (d.sleeves) Prim(cube, arm, new Vector3(0f, -0.1f, 0f), new Vector3(0.18f, 0.24f, 0.18f), d.shirt);
            }
            return r;
        }

        static void PoseLimbs(Rig r, float legA, float armA, float lean)
        {
            r.legL.localRotation = Quaternion.Euler(legA, 0f, 0f);
            r.legR.localRotation = Quaternion.Euler(-legA, 0f, 0f);
            r.armL.localRotation = Quaternion.Euler(-armA, 0f, -4f);
            r.armR.localRotation = Quaternion.Euler(armA, 0f, 4f);
            r.body.localRotation = Quaternion.Euler(lean, 0f, 0f);
        }

        // ---------- the player ----------
        Rig pr;
        float runPhase;

        void BuildPlayer()
        {
            bool first = player == null;
            if (first) player = new GameObject("Player").transform;
            else
            {
                for (int i = player.childCount - 1; i >= 0; i--)
                {
                    var c = player.GetChild(i);
                    c.SetParent(null);
                    Destroy(c.gameObject);
                }
            }
            pr = BuildHuman(player, Chars[charIdx]);
            if (first) player.position = new Vector3(0f, 0.9f, 0f);
        }

        void AnimatePlayer(float dt)
        {
            if (pr == null) return;

            // blink while invulnerable after using an extra life
            bool blink = state == State.Playing && invulnT > 0f && ((int)(Time.time * 14f) % 2 == 0);
            pr.body.gameObject.SetActive(!blink);

            if (state == State.Menu)
            {
                // showcase pose: slow spin, friendly wave
                menuSpin += dt * 50f;
                player.rotation = Quaternion.Euler(0f, menuSpin, 0f);
                PoseLimbs(pr, 0f, Mathf.Sin(Time.time * 2f) * 5f, 0f);
                pr.armR.localRotation = Quaternion.Euler(0f, 0f, 140f + Mathf.Sin(Time.time * 7f) * 18f);
                return;
            }
            player.rotation = Quaternion.identity;

            float legA = 0f, armA = 0f, lean = 0f;
            if (state == State.Playing)
            {
                if (py > 0.001f)
                {
                    // airborne pose: knees up front, arms out
                    pr.legL.localRotation = Quaternion.Euler(-55f, 0f, 0f);
                    pr.legR.localRotation = Quaternion.Euler(25f, 0f, 0f);
                    pr.armL.localRotation = Quaternion.Euler(0f, 0f, -150f);
                    pr.armR.localRotation = Quaternion.Euler(0f, 0f, 150f);
                    pr.body.localRotation = Quaternion.identity;
                    return;
                }
                runPhase += dt * (9f + speed * 0.35f);
                float sw = Mathf.Sin(runPhase);
                legA = sw * 50f;
                armA = -sw * 55f;
                lean = 8f;
            }
            PoseLimbs(pr, legA, armA, lean);
        }
    }
}
