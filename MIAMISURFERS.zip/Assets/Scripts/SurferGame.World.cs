using System.Collections.Generic;
using UnityEngine;

namespace MiniSurfers
{
    // The scenery: scrolling street segments, beach crowd, lamps, neon signs, and the living sky.
    public partial class SurferGame
    {
        class Npc
        {
            public Rig rig;
            public Transform root;
            public int mode; // 0 sunbather, 1 walker/skater, 2 volleyball, 3 surfer, 4 ice-cream vendor
            public float x0, baseY, z, dir = 1f, spd, phase, amp, rate;
        }

        class Segment
        {
            public Transform t;
            public Transform[] buildings, windows, signs, waves;
            public float[] waveX;
            public readonly List<Npc> npcs = new List<Npc>();
            public GameObject volley, surfer, vendor, extras;
            public Transform ball;
        }

        class Gull { public Transform root, wingL, wingR; public float dir, spd, phase; }

        static readonly Color[] Pastels =
        {
            new Color(1f, 0.70f, 0.80f), new Color(0.70f, 1f, 0.90f), new Color(1f, 0.85f, 0.60f),
            new Color(0.75f, 0.80f, 1f), new Color(0.60f, 0.95f, 1f), new Color(1f, 0.95f, 0.60f)
        };

        static readonly Color[] Neons =
        {
            new Color(1f, 0.25f, 0.65f), new Color(0.2f, 1f, 1f), new Color(1f, 0.9f, 0.2f),
            new Color(0.5f, 1f, 0.4f), new Color(0.75f, 0.4f, 1f)
        };

        // sky objects
        Transform sunT, moonT;
        Transform[] stars, clouds;
        float[] cloudSpd;
        readonly List<Gull> gulls = new List<Gull>();
        int skyIdx;

        void BuildMaterials()
        {
            windowMat = NewMat(new Color(0.75f, 0.82f, 0.95f));
            lampMat = NewMat(new Color(0.85f, 0.85f, 0.8f));
            cloudMat = NewMat(Color.white);
            sunMat = NewMat(new Color(1f, 0.9f, 0.5f));
        }

        // ---------- street segments ----------
        void BuildWorld()
        {
            world = new GameObject("World").transform;
            for (int i = 0; i < SegCount; i++)
            {
                var s = MakeSegment();
                s.t.position = new Vector3(0f, 0f, -SegLen + i * SegLen);
                segments.Add(s);
            }
        }

        Segment MakeSegment()
        {
            var go = new GameObject("Segment");
            go.transform.SetParent(world, false);
            var t = go.transform;
            var cube = PrimitiveType.Cube;
            var seg = new Segment { t = t };

            // road + neon lines
            Prim(cube, t, new Vector3(0f, -0.1f, 0f), new Vector3(7f, 0.2f, SegLen), new Color(0.20f, 0.20f, 0.26f));
            Prim(cube, t, new Vector3(-1f, 0.01f, 0f), new Vector3(0.08f, 0.02f, SegLen), new Color(0.3f, 1f, 1f));
            Prim(cube, t, new Vector3(1f, 0.01f, 0f), new Vector3(0.08f, 0.02f, SegLen), new Color(0.3f, 1f, 1f));
            Prim(cube, t, new Vector3(-3.4f, 0.01f, 0f), new Vector3(0.15f, 0.02f, SegLen), new Color(1f, 0.3f, 0.7f));
            Prim(cube, t, new Vector3(3.4f, 0.01f, 0f), new Vector3(0.15f, 0.02f, SegLen), new Color(1f, 0.3f, 0.7f));

            // sidewalks
            var walk = new Color(0.96f, 0.86f, 0.82f);
            Prim(cube, t, new Vector3(-5.2f, 0f, 0f), new Vector3(3.4f, 0.4f, SegLen), walk);
            Prim(cube, t, new Vector3(5.2f, 0f, 0f), new Vector3(3.4f, 0.4f, SegLen), walk);

            // LEFT: beach, foam, ocean
            Prim(cube, t, new Vector3(-9.95f, -0.05f, 0f), new Vector3(6.2f, 0.3f, SegLen), new Color(0.96f, 0.88f, 0.65f));
            Prim(cube, t, new Vector3(-13.2f, -0.08f, 0f), new Vector3(0.6f, 0.2f, SegLen), new Color(1f, 1f, 1f));
            Prim(cube, t, new Vector3(-38f, -0.2f, 0f), new Vector3(50f, 0.2f, SegLen), new Color(0.10f, 0.78f, 0.88f));

            // animated wave crests
            seg.waveX = new[] { -16f, -22f, -30f };
            seg.waves = new Transform[3];
            for (int i = 0; i < 3; i++)
                seg.waves[i] = Prim(cube, t, new Vector3(seg.waveX[i], -0.07f, Random.Range(-7f, 7f)),
                    new Vector3(0.5f, 0.05f, Random.Range(4f, 7f)), new Color(0.85f, 1f, 1f)).transform;

            // RIGHT: ground behind the buildings
            Prim(cube, t, new Vector3(18.5f, -0.1f, 0f), new Vector3(23.2f, 0.2f, SegLen), new Color(0.84f, 0.78f, 0.80f));

            // beach umbrella + towel
            float uz = Random.Range(-7f, 7f);
            var umbrellaColor = Pastels[Random.Range(0, Pastels.Length)];
            Prim(PrimitiveType.Cylinder, t, new Vector3(-10f, 1f, uz), new Vector3(0.06f, 1f, 0.06f), new Color(0.9f, 0.9f, 0.9f));
            Prim(PrimitiveType.Sphere, t, new Vector3(-10f, 2.05f, uz), new Vector3(2.2f, 0.6f, 2.2f), umbrellaColor);
            Prim(cube, t, new Vector3(-9.2f, 0.12f, uz + 1.6f), new Vector3(1.2f, 0.03f, 2f), new Color(1f, 0.45f, 0.65f));

            // little bollards along the beach edge
            for (int i = 0; i < 4; i++)
                Prim(PrimitiveType.Cylinder, t, new Vector3(-7.05f, 0.35f, -7.5f + i * 5f), new Vector3(0.12f, 0.25f, 0.12f),
                    i % 2 == 0 ? new Color(1f, 0.45f, 0.7f) : Color.white);

            // street lamps (glow at night)
            MakeLamp(t, -3.75f, -5f, 1f);
            MakeLamp(t, 3.75f, 5f, -1f);

            // palm trees
            MakePalm(t, new Vector3(-7.6f, 0.1f, -6f), Random.Range(-8f, 8f), Random.Range(0f, 360f));
            MakePalm(t, new Vector3(-7.9f, 0.1f, 4f), Random.Range(-8f, 8f), Random.Range(0f, 360f));
            MakePalm(t, new Vector3(7.4f, 0.2f, -2f), Random.Range(-8f, 8f), Random.Range(0f, 360f));
            MakePalm(t, new Vector3(7.6f, 0.2f, 8f), Random.Range(-8f, 8f), Random.Range(0f, 360f));

            // pastel art-deco buildings (two rows on the right)
            seg.buildings = new Transform[4];
            float[] xs = { 10f, 10f, 18f, 18f };
            float[] zs = { -5f, 5f, -5f, 5f };
            for (int i = 0; i < 4; i++)
            {
                var b = Prim(cube, t, new Vector3(xs[i], 3f, zs[i]), new Vector3(4f, 6f, 8f), Pastels[Random.Range(0, Pastels.Length)]);
                seg.buildings[i] = b.transform;
            }

            // lit windows + neon signs on the two buildings facing the street
            seg.windows = new Transform[16];
            for (int i = 0; i < 16; i++)
                seg.windows[i] = PrimM(cube, t, Vector3.zero, new Vector3(0.05f, 0.7f, 0.9f), windowMat).transform;
            seg.signs = new Transform[2];
            for (int i = 0; i < 2; i++)
                seg.signs[i] = Prim(cube, t, Vector3.zero, new Vector3(0.1f, 0.6f, 3f), Neons[Random.Range(0, Neons.Length)]).transform;

            PopulateSegment(seg);
            RandomizeSegment(seg);
            return seg;
        }

        void MakeLamp(Transform parent, float x, float z, float dirX)
        {
            var steel = new Color(0.25f, 0.25f, 0.3f);
            Prim(PrimitiveType.Cylinder, parent, new Vector3(x, 1.9f, z), new Vector3(0.12f, 1.7f, 0.12f), steel);
            Prim(PrimitiveType.Cube, parent, new Vector3(x + dirX * 0.45f, 3.55f, z), new Vector3(0.9f, 0.08f, 0.08f), steel);
            PrimM(PrimitiveType.Sphere, parent, new Vector3(x + dirX * 0.9f, 3.45f, z), new Vector3(0.32f, 0.22f, 0.32f), lampMat);
        }

        void MakePalm(Transform parent, Vector3 pos, float lean, float yaw)
        {
            var root = new GameObject("Palm").transform;
            root.SetParent(parent, false);
            root.localPosition = pos;
            root.localRotation = Quaternion.Euler(0f, yaw, lean);
            float h = Random.Range(4f, 6f);
            Prim(PrimitiveType.Cylinder, root, new Vector3(0f, h * 0.5f, 0f), new Vector3(0.35f, h * 0.5f, 0.35f), new Color(0.55f, 0.38f, 0.22f));
            var crown = new GameObject("Crown").transform;
            crown.SetParent(root, false);
            crown.localPosition = new Vector3(0f, h, 0f);
            var green = Random.value > 0.5f ? new Color(0.15f, 0.65f, 0.25f) : new Color(0.20f, 0.75f, 0.35f);
            for (int i = 0; i < 7; i++)
            {
                var pivot = new GameObject("Frond").transform;
                pivot.SetParent(crown, false);
                pivot.localRotation = Quaternion.Euler(0f, i * (360f / 7f), 0f);
                var leaf = Prim(PrimitiveType.Cube, pivot, new Vector3(0f, 0f, 1.1f), new Vector3(0.5f, 0.06f, 2.2f), green);
                leaf.transform.localRotation = Quaternion.Euler(22f, 0f, 0f);
            }
            Prim(PrimitiveType.Sphere, crown, new Vector3(0.15f, -0.2f, 0.1f), new Vector3(0.3f, 0.3f, 0.3f), new Color(0.3f, 0.2f, 0.1f));
            Prim(PrimitiveType.Sphere, crown, new Vector3(-0.15f, -0.2f, -0.1f), new Vector3(0.3f, 0.3f, 0.3f), new Color(0.3f, 0.2f, 0.1f));
        }

        // ---------- the beach crowd ----------
        Npc AddNpc(Segment seg, Transform parent, int mode, Vector3 pos, float yaw)
        {
            var root = new GameObject("Npc").transform;
            root.SetParent(parent, false);
            root.localPosition = pos;
            root.localRotation = Quaternion.Euler(0f, yaw, 0f);
            var n = new Npc { root = root, mode = mode, x0 = pos.x, baseY = pos.y, z = pos.z, phase = Random.value * 6.28f };
            n.rig = BuildHuman(root, NpcVariant());
            seg.npcs.Add(n);
            return n;
        }

        GameObject NewGroup(Segment seg, string name)
        {
            var g = new GameObject(name);
            g.transform.SetParent(seg.t, false);
            return g;
        }

        void PopulateSegment(Segment seg)
        {
            var t = seg.t;
            var cube = PrimitiveType.Cube;

            // sunbather on a towel (lying face-up, head toward the camera)
            var sb = AddNpc(seg, t, 0, new Vector3(-11.2f, 0.36f, 0f), 0f);
            sb.root.localRotation = Quaternion.Euler(-90f, 0f, 0f);
            Prim(cube, sb.root, new Vector3(0f, 0f, -0.26f), new Vector3(1.3f, 2.3f, 0.03f), Pastels[Random.Range(0, Pastels.Length)]);

            // strollers (left sidewalk) and a roller-skater (right sidewalk)
            var w1 = AddNpc(seg, t, 1, new Vector3(-4.6f, 1.12f, 0f), 0f);
            w1.spd = Random.Range(1.2f, 2f); w1.amp = 35f; w1.rate = 7f;
            var w2 = AddNpc(seg, t, 1, new Vector3(5.9f, 1.12f, 0f), 0f);
            w2.spd = Random.Range(4f, 6f); w2.amp = 22f; w2.rate = 5f;

            // beach volleyball
            seg.volley = NewGroup(seg, "Volley");
            var vt = seg.volley.transform;
            Prim(cube, vt, new Vector3(0f, 1.15f, 0f), new Vector3(0.03f, 0.6f, 3.2f), new Color(0.95f, 0.95f, 0.95f));
            Prim(PrimitiveType.Cylinder, vt, new Vector3(0f, 0.8f, -1.65f), new Vector3(0.08f, 0.8f, 0.08f), new Color(0.5f, 0.5f, 0.55f));
            Prim(PrimitiveType.Cylinder, vt, new Vector3(0f, 0.8f, 1.65f), new Vector3(0.08f, 0.8f, 0.08f), new Color(0.5f, 0.5f, 0.55f));
            var va = AddNpc(seg, vt, 2, new Vector3(-0.95f, 0.92f, 0f), 90f); va.phase = Mathf.PI;
            var vb = AddNpc(seg, vt, 2, new Vector3(0.95f, 0.92f, 0f), -90f); vb.phase = 0f;
            seg.ball = Prim(PrimitiveType.Sphere, vt, new Vector3(0f, 1.5f, 0f), new Vector3(0.3f, 0.3f, 0.3f), Color.white).transform;

            // surfer riding a board in the water (faces the camera)
            seg.surfer = NewGroup(seg, "Surfer");
            var st = seg.surfer.transform;
            Prim(cube, st, new Vector3(0f, 0.04f, 0f), new Vector3(2.2f, 0.08f, 0.7f), Neons[Random.Range(0, Neons.Length)]);
            AddNpc(seg, st, 3, new Vector3(0f, 0.97f, 0f), 180f);

            // ice-cream vendor waving from his cart
            seg.vendor = NewGroup(seg, "Vendor");
            var vn = seg.vendor.transform;
            Prim(cube, vn, new Vector3(0f, 0.5f, 0f), new Vector3(1.3f, 0.7f, 0.8f), Pastels[Random.Range(0, Pastels.Length)]);
            Prim(cube, vn, new Vector3(0f, 0.9f, 0f), new Vector3(1.4f, 0.08f, 0.9f), Color.white);
            Prim(PrimitiveType.Sphere, vn, new Vector3(-0.4f, 1.05f, 0f), new Vector3(0.22f, 0.22f, 0.22f), new Color(1f, 0.5f, 0.7f));
            Prim(PrimitiveType.Sphere, vn, new Vector3(0f, 1.05f, 0f), new Vector3(0.22f, 0.22f, 0.22f), new Color(0.6f, 1f, 0.8f));
            Prim(PrimitiveType.Sphere, vn, new Vector3(0.4f, 1.05f, 0f), new Vector3(0.22f, 0.22f, 0.22f), new Color(1f, 0.95f, 0.5f));
            Prim(PrimitiveType.Cylinder, vn, new Vector3(0.5f, 1.6f, 0.3f), new Vector3(0.06f, 0.7f, 0.06f), new Color(0.7f, 0.7f, 0.7f));
            Prim(PrimitiveType.Sphere, vn, new Vector3(0.5f, 2.3f, 0.3f), new Vector3(1.8f, 0.5f, 1.8f), Neons[Random.Range(0, Neons.Length)]);
            AddNpc(seg, vn, 4, new Vector3(-1.2f, 0.92f, 0.2f), 180f);

            // lifeguard tower + sandcastle
            seg.extras = NewGroup(seg, "Extras");
            var et = seg.extras.transform;
            var steel = new Color(0.6f, 0.45f, 0.3f);
            foreach (var sx in new[] { -0.6f, 0.6f })
                foreach (var sz in new[] { -0.6f, 0.6f })
                    Prim(PrimitiveType.Cylinder, et, new Vector3(sx, 0.7f, sz), new Vector3(0.07f, 0.7f, 0.07f), steel);
            Prim(cube, et, new Vector3(0f, 1.45f, 0f), new Vector3(1.6f, 0.1f, 1.6f), steel);
            Prim(cube, et, new Vector3(0f, 1.95f, 0f), new Vector3(1.3f, 0.9f, 1.3f), new Color(0.96f, 0.96f, 0.96f));
            Prim(cube, et, new Vector3(0f, 2.05f, 0f), new Vector3(1.32f, 0.2f, 1.32f), new Color(1f, 0.3f, 0.4f));
            Prim(cube, et, new Vector3(0f, 2.5f, 0f), new Vector3(1.8f, 0.08f, 1.8f), new Color(1f, 0.3f, 0.4f));
            Prim(PrimitiveType.Cylinder, et, new Vector3(0.6f, 2.95f, 0.6f), new Vector3(0.03f, 0.5f, 0.03f), Color.white);
            Prim(cube, et, new Vector3(0.82f, 3.25f, 0.6f), new Vector3(0.4f, 0.25f, 0.02f), new Color(1f, 0.85f, 0.2f));
            Prim(cube, et, new Vector3(1.9f, 0.15f, 0.5f), new Vector3(0.6f, 0.3f, 0.6f), new Color(0.9f, 0.78f, 0.5f));
            Prim(cube, et, new Vector3(1.9f, 0.4f, 0.5f), new Vector3(0.3f, 0.25f, 0.3f), new Color(0.9f, 0.78f, 0.5f));
        }

        void ResetNpc(Npc n)
        {
            if (n.mode == 0)
            {
                n.z = Random.Range(-8f, 8f);
                n.root.localPosition = new Vector3(n.x0, n.baseY, n.z);
            }
            else if (n.mode == 1)
            {
                n.z = Random.Range(-8f, 8f);
                n.dir = Random.value > 0.5f ? 1f : -1f;
            }
        }

        void RandomizeSegment(Segment s)
        {
            RandomizeBuildings(s);
            foreach (var n in s.npcs)
            {
                ResetNpc(n);
                // keep the crowd sparse: only some people show up on each stretch
                if (n.mode == 0) n.root.gameObject.SetActive(Random.value < 0.3f);
                else if (n.mode == 1) n.root.gameObject.SetActive(Random.value < 0.25f);
            }

            s.volley.SetActive(Random.value < 0.15f);
            s.volley.transform.localPosition = new Vector3(-8.4f, 0.1f, Random.Range(-6f, 6f));
            s.surfer.SetActive(Random.value < 0.25f);
            s.surfer.transform.localPosition = new Vector3(Random.Range(-19f, -16f), -0.1f, Random.Range(-7f, 7f));
            s.vendor.SetActive(Random.value < 0.12f);
            s.vendor.transform.localPosition = new Vector3(5.9f, 0.2f, Random.Range(-6f, 6f));
            s.extras.SetActive(Random.value < 0.25f);
            s.extras.transform.localPosition = new Vector3(-12.3f, 0.1f, Random.Range(-6f, 6f));
        }

        void RandomizeBuildings(Segment s)
        {
            foreach (var b in s.buildings)
            {
                var p = b.localPosition;
                float h = p.x > 13f ? Random.Range(8f, 20f) : Random.Range(4f, 10f);
                b.localScale = new Vector3(4f, h, 8f);
                b.localPosition = new Vector3(p.x, h * 0.5f, p.z);
            }

            // windows + signs on the two street-facing buildings (face is at x = 8)
            for (int bi = 0; bi < 2; bi++)
            {
                var b = s.buildings[bi];
                float h = b.localScale.y;
                float zc = b.localPosition.z;
                for (int r = 0; r < 4; r++)
                {
                    float y = 1.5f + r * 1.7f;
                    for (int c = 0; c < 2; c++)
                    {
                        var wnd = s.windows[bi * 8 + r * 2 + c];
                        bool on = y < h - 0.6f && Random.value > 0.2f;
                        wnd.gameObject.SetActive(on);
                        wnd.localPosition = new Vector3(7.97f, y, zc + (c == 0 ? -2f : 2f));
                    }
                }
                var sign = s.signs[bi];
                sign.localPosition = new Vector3(7.93f, Random.Range(2f, Mathf.Max(2.5f, h - 1.5f)), zc + Random.Range(-1.2f, 1.2f));
                sign.GetComponent<Renderer>().sharedMaterial = GetMat(Neons[Random.Range(0, Neons.Length)]);
            }
        }

        void ScrollWorld(float dt)
        {
            foreach (var s in segments) s.t.position -= new Vector3(0f, 0f, speed * dt);
            foreach (var s in segments)
            {
                if (s.t.position.z < -1.5f * SegLen)
                {
                    float maxZ = float.MinValue;
                    foreach (var o in segments) if (o.t.position.z > maxZ) maxZ = o.t.position.z;
                    s.t.position = new Vector3(0f, 0f, maxZ + SegLen);
                    RandomizeSegment(s);
                }
            }
        }

        // ---------- living scenery ----------
        void UpdateWorldLife(float dt)
        {
            float tm = Time.time;
            foreach (var s in segments)
            {
                for (int i = 0; i < s.waves.Length; i++)
                {
                    var p = s.waves[i].localPosition;
                    p.x = s.waveX[i] + Mathf.Sin(tm * 1.3f + i * 2f + s.t.position.z * 0.1f) * 0.8f;
                    s.waves[i].localPosition = p;
                }
                if (s.surfer.activeSelf)
                {
                    var g = s.surfer.transform;
                    var gp = g.localPosition;
                    gp.y = -0.05f + Mathf.Sin(tm * 1.5f + gp.z) * 0.12f;
                    g.localPosition = gp;
                    g.localRotation = Quaternion.Euler(0f, 0f, Mathf.Sin(tm * 1.5f + gp.z) * 5f);
                }
                if (s.volley.activeSelf)
                {
                    s.ball.localPosition = new Vector3(Mathf.Sin(tm * 2f) * 0.9f, 1.2f + Mathf.Abs(Mathf.Cos(tm * 2f)) * 1.4f, 0f);
                }
                foreach (var n in s.npcs)
                {
                    if (!n.root.gameObject.activeInHierarchy) continue;
                    AnimateNpc(n, dt, tm);
                }
            }

            // drifting clouds
            for (int i = 0; i < clouds.Length; i++)
            {
                var p = clouds[i].position;
                p.x += cloudSpd[i] * dt;
                if (p.x > 90f) p.x = -90f;
                clouds[i].position = p;
            }

            // seagulls
            foreach (var g in gulls)
            {
                var p = g.root.position;
                p.x += g.dir * g.spd * dt;
                p.z -= speed * 0.15f * dt;
                if (p.z < 8f) p.z = 48f;
                if (p.x > 55f) p.x = -55f;
                if (p.x < -55f) p.x = 55f;
                p.y += Mathf.Sin(tm * 1.7f + g.phase) * 0.4f * dt;
                g.root.position = p;
                float flap = Mathf.Sin(tm * 9f + g.phase) * 35f;
                g.wingL.localRotation = Quaternion.Euler(0f, 0f, flap);
                g.wingR.localRotation = Quaternion.Euler(0f, 0f, -flap);
            }
        }

        void AnimateNpc(Npc n, float dt, float tm)
        {
            switch (n.mode)
            {
                case 1:
                {
                    n.z += n.dir * n.spd * dt;
                    if (n.z > 9f) { n.z = 9f; n.dir = -1f; }
                    else if (n.z < -9f) { n.z = -9f; n.dir = 1f; }
                    n.root.localPosition = new Vector3(n.x0, n.baseY, n.z);
                    n.root.localRotation = Quaternion.Euler(0f, n.dir > 0f ? 0f : 180f, 0f);
                    n.phase += dt * n.rate;
                    float sw = Mathf.Sin(n.phase);
                    PoseLimbs(n.rig, sw * n.amp, -sw * n.amp, 4f);
                    break;
                }
                case 2:
                {
                    float j = Mathf.Max(0f, Mathf.Sin(tm * 2f + n.phase));
                    j = j * j;
                    var lp = n.root.localPosition;
                    lp.y = n.baseY + j * 0.7f;
                    n.root.localPosition = lp;
                    float up = j > 0.15f ? 150f : 25f;
                    n.rig.armL.localRotation = Quaternion.Euler(0f, 0f, -up);
                    n.rig.armR.localRotation = Quaternion.Euler(0f, 0f, up);
                    n.rig.legL.localRotation = Quaternion.Euler(-j * 25f, 0f, 0f);
                    n.rig.legR.localRotation = Quaternion.Euler(j * 25f, 0f, 0f);
                    break;
                }
                case 3:
                {
                    float wob = Mathf.Sin(tm * 1.5f + n.phase);
                    n.rig.armL.localRotation = Quaternion.Euler(0f, 0f, -75f + wob * 15f);
                    n.rig.armR.localRotation = Quaternion.Euler(0f, 0f, 75f - wob * 15f);
                    n.rig.legL.localRotation = Quaternion.Euler(0f, 0f, -6f);
                    n.rig.legR.localRotation = Quaternion.Euler(0f, 0f, 6f);
                    n.rig.body.localRotation = Quaternion.Euler(0f, 0f, wob * 6f);
                    break;
                }
                case 4:
                    n.rig.armR.localRotation = Quaternion.Euler(0f, 0f, 150f + Mathf.Sin(tm * 7f + n.phase) * 20f);
                    break;
            }
        }

        // ---------- sky ----------
        static readonly string[] SkyNames = { "SUNSET", "DUSK", "MIDNIGHT", "SUNRISE", "SUNNY DAY" };
        static readonly Color[] SkyCol =
        {
            new Color(1f, 0.66f, 0.58f), new Color(0.62f, 0.36f, 0.62f), new Color(0.04f, 0.06f, 0.20f),
            new Color(1f, 0.72f, 0.50f), new Color(0.45f, 0.78f, 1f)
        };
        static readonly Color[] AmbCol =
        {
            new Color(0.72f, 0.62f, 0.68f), new Color(0.48f, 0.40f, 0.60f), new Color(0.28f, 0.32f, 0.50f),
            new Color(0.75f, 0.65f, 0.62f), new Color(0.80f, 0.82f, 0.90f)
        };
        static readonly Color[] LightCol =
        {
            new Color(1f, 0.85f, 0.72f), new Color(0.9f, 0.6f, 0.7f), new Color(0.55f, 0.65f, 1f),
            new Color(1f, 0.8f, 0.6f), new Color(1f, 0.97f, 0.9f)
        };
        static readonly float[] LightInt = { 0.9f, 0.75f, 0.55f, 0.85f, 1.1f };
        static readonly float[] NightAmt = { 0f, 0.35f, 1f, 0.15f, 0f };
        static readonly float[] SunY = { 24f, 8f, -34f, 10f, 42f };
        static readonly Color[] SunCol =
        {
            new Color(1f, 0.9f, 0.5f), new Color(1f, 0.5f, 0.35f), new Color(1f, 0.5f, 0.3f),
            new Color(1f, 0.7f, 0.3f), new Color(1f, 0.98f, 0.7f)
        };
        static readonly Color[] CloudCol =
        {
            new Color(1f, 0.85f, 0.85f), new Color(0.9f, 0.6f, 0.75f), new Color(0.25f, 0.30f, 0.50f),
            new Color(1f, 0.75f, 0.65f), new Color(1f, 1f, 1f)
        };

        void BuildSky()
        {
            sunT = PrimM(PrimitiveType.Sphere, null, new Vector3(0f, 24f, 115f), new Vector3(32f, 32f, 32f), sunMat).transform;
            sunT.name = "Sun";

            moonT = Prim(PrimitiveType.Sphere, null, new Vector3(-38f, 40f, 118f), Vector3.zero, new Color(0.95f, 0.95f, 1f)).transform;
            moonT.name = "Moon";

            stars = new Transform[70];
            for (int i = 0; i < stars.Length; i++)
            {
                stars[i] = Prim(PrimitiveType.Cube, null,
                    new Vector3(Random.Range(-100f, 100f), Random.Range(14f, 60f), Random.Range(100f, 125f)),
                    Vector3.zero, Color.white).transform;
            }

            clouds = new Transform[9];
            cloudSpd = new float[clouds.Length];
            for (int i = 0; i < clouds.Length; i++)
            {
                var root = new GameObject("Cloud").transform;
                root.position = new Vector3(Random.Range(-85f, 85f), Random.Range(22f, 40f), Random.Range(92f, 125f));
                for (int k = 0; k < 4; k++)
                {
                    PrimM(PrimitiveType.Sphere, root,
                        new Vector3(Random.Range(-6f, 6f), Random.Range(-0.5f, 1f), Random.Range(-1.5f, 1.5f)),
                        new Vector3(Random.Range(8f, 12f), Random.Range(2.5f, 3.6f), Random.Range(4f, 6f)), cloudMat);
                }
                clouds[i] = root;
                cloudSpd[i] = Random.Range(0.6f, 1.6f);
            }

            for (int i = 0; i < 4; i++)
            {
                var root = new GameObject("Gull").transform;
                root.position = new Vector3(Random.Range(-50f, 50f), Random.Range(8f, 14f), Random.Range(18f, 46f));
                Prim(PrimitiveType.Cube, root, Vector3.zero, new Vector3(0.25f, 0.12f, 0.5f), Color.white);
                var wl = Pivot(root, new Vector3(-0.1f, 0.05f, 0f));
                var wr = Pivot(root, new Vector3(0.1f, 0.05f, 0f));
                Prim(PrimitiveType.Cube, wl, new Vector3(-0.45f, 0f, 0f), new Vector3(0.9f, 0.03f, 0.25f), Color.white);
                Prim(PrimitiveType.Cube, wr, new Vector3(0.45f, 0f, 0f), new Vector3(0.9f, 0.03f, 0.25f), Color.white);
                float dir = Random.value > 0.5f ? 1f : -1f;
                root.rotation = Quaternion.Euler(0f, dir > 0f ? 90f : -90f, 0f);
                gulls.Add(new Gull { root = root, wingL = wl, wingR = wr, dir = dir, spd = Random.Range(4f, 7f), phase = Random.value * 6.28f });
            }
        }

        // Day/night cycle: sunset -> dusk -> midnight -> sunrise -> sunny day -> sunset ...
        void UpdateSky(float dt)
        {
            int n = SkyCol.Length;
            float p = dist / 420f;
            int i = Mathf.FloorToInt(p) % n;
            int j = (i + 1) % n;
            float f = p - Mathf.Floor(p);
            f = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((f - 0.3f) / 0.7f));

            if (i != skyIdx)
            {
                skyIdx = i;
                if (state == State.Playing) { bannerT = 3f; bannerText = SkyNames[i]; }
            }

            var sky = Color.Lerp(SkyCol[i], SkyCol[j], f);
            cam.backgroundColor = sky;
            RenderSettings.fogColor = sky;
            RenderSettings.ambientLight = Color.Lerp(AmbCol[i], AmbCol[j], f);
            if (sunLight != null)
            {
                sunLight.color = Color.Lerp(LightCol[i], LightCol[j], f);
                sunLight.intensity = Mathf.Lerp(LightInt[i], LightInt[j], f);
            }
            float night = Mathf.Lerp(NightAmt[i], NightAmt[j], f);

            float sy = Mathf.Lerp(SunY[i], SunY[j], f);
            sunT.gameObject.SetActive(sy > -12f);
            sunT.position = new Vector3(0f, sy, 115f);
            SetMatColor(sunMat, Color.Lerp(SunCol[i], SunCol[j], f));

            float moonS = 11f * Mathf.Clamp01((night - 0.3f) / 0.7f);
            moonT.localScale = new Vector3(moonS, moonS, moonS);
            float starS = 0.6f * Mathf.Clamp01((night - 0.4f) / 0.6f);
            foreach (var s in stars) s.localScale = new Vector3(starS, starS, starS);

            SetMatColor(cloudMat, Color.Lerp(CloudCol[i], CloudCol[j], f));
            float glow = Mathf.Clamp01(night * 1.6f);
            SetMatColor(windowMat, Color.Lerp(new Color(0.75f, 0.82f, 0.95f), new Color(1f, 0.88f, 0.45f), glow));
            SetMatColor(lampMat, Color.Lerp(new Color(0.85f, 0.85f, 0.8f), new Color(1f, 0.96f, 0.6f), glow));
        }
    }
}
