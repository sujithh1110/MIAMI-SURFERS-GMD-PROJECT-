using UnityEngine;

namespace MiniSurfers
{
    // IMGUI heads-up display, runner-select screen and game-over screen.
    public partial class SurferGame
    {
        Texture2D circleTex;
        float bannerT;
        string bannerText = "";

        static readonly Color Pink = new Color(1f, 0.35f, 0.7f);
        static readonly Color Cyan = new Color(0.3f, 1f, 1f);
        static readonly Color Gold = new Color(1f, 0.9f, 0.2f);

        Texture2D MakeCircle(int s)
        {
            var tx = new Texture2D(s, s, TextureFormat.RGBA32, false);
            tx.filterMode = FilterMode.Bilinear;
            var mid = new Vector2(s * 0.5f, s * 0.5f);
            for (int y = 0; y < s; y++)
                for (int x = 0; x < s; x++)
                {
                    float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), mid);
                    tx.SetPixel(x, y, new Color(1f, 1f, 1f, Mathf.Clamp01(s * 0.5f - d)));
                }
            tx.Apply();
            return tx;
        }

        void Label(Rect r, string t, TextAnchor a, int size, Color c)
        {
            style.fontSize = size;
            style.alignment = a;
            style.normal.textColor = new Color(0f, 0f, 0f, c.a);
            var rr = r; rr.x += 2f; rr.y += 2f;
            GUI.Label(rr, t, style);
            style.normal.textColor = c;
            GUI.Label(r, t, style);
        }

        void Box(Rect r, Color c)
        {
            GUI.color = c;
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = Color.white;
        }

        void Dot(Rect r, Color c)
        {
            GUI.color = c;
            GUI.DrawTexture(r, circleTex);
            GUI.color = Color.white;
        }

        // translucent dark panel with a coloured top and bottom edge
        void Panel(Rect r, Color edge)
        {
            Box(r, new Color(0.05f, 0.03f, 0.12f, 0.62f));
            Box(new Rect(r.x, r.y, r.width, 3f), edge);
            Box(new Rect(r.x, r.yMax - 3f, r.width, 3f), edge);
        }

        void Bar(Rect r, float fill, Color c)
        {
            Box(r, new Color(0f, 0f, 0f, 0.45f));
            Box(new Rect(r.x, r.y, r.width * Mathf.Clamp01(fill), r.height), c);
        }

        // ---------- runner-select layout (also used for tap hit-testing) ----------
        Rect prevR, nextR;

        Rect MenuPanel()
        {
            float w = Screen.width, h = Screen.height;
            float pw = Mathf.Min(w * 0.92f, h * 1.35f);
            return new Rect(w * 0.5f - pw * 0.5f, h * 0.64f, pw, h * 0.31f);
        }

        void LayoutMenu()
        {
            float h = Screen.height;
            var p = MenuPanel();
            float bs = Mathf.Max(48f, h * 0.09f);
            float cy = p.y + h * 0.045f;
            prevR = new Rect(p.x + bs * 0.3f, cy - bs * 0.5f, bs, bs);
            nextR = new Rect(p.xMax - bs * 1.3f, cy - bs * 0.5f, bs, bs);
        }

        bool TryMenuClick(Vector2 m)
        {
            if (state != State.Menu) return false;
            LayoutMenu();
            if (prevR.Contains(m)) { ChangeChar(-1); return true; }
            if (nextR.Contains(m)) { ChangeChar(1); return true; }
            return false;
        }

        // ---------- drawing ----------
        void DrawHud()
        {
            if (style == null)
            {
                style = new GUIStyle(GUI.skin.label);
                style.fontStyle = FontStyle.Bold;
                style.wordWrap = false;
            }
            if (circleTex == null) circleTex = MakeCircle(64);

            float w = Screen.width, h = Screen.height;
            int big = Mathf.Max(30, (int)(h / 10f));
            int mid = Mathf.Max(18, (int)(h / 24f));
            int small = Mathf.Max(13, (int)(h / 34f));
            var C = Chars[charIdx];

            if (flash > 0f)
            {
                GUI.color = new Color(1f, 0f, 0f, flash * 0.4f);
                GUI.DrawTexture(new Rect(0, 0, w, h), Texture2D.whiteTexture);
                GUI.color = Color.white;
            }

            // score + coin panels
            float pw = Mathf.Max(170f, w * 0.2f), ph = mid * 2.7f;
            Panel(new Rect(12f, 12f, pw, ph), Pink);
            Label(new Rect(24f, 16f, pw, small * 1.6f), "SCORE", TextAnchor.UpperLeft, small, new Color(1f, 0.7f, 0.85f));
            Label(new Rect(24f, 16f + small * 1.2f, pw, mid * 1.8f), Mathf.FloorToInt(score).ToString(), TextAnchor.UpperLeft, (int)(mid * 1.3f), Color.white);

            float cx = w - 12f - pw;
            Panel(new Rect(cx, 12f, pw, ph), Gold);
            Dot(new Rect(cx + 14f, 12f + ph * 0.5f - mid * 0.6f, mid * 1.2f, mid * 1.2f), Gold);
            Dot(new Rect(cx + 14f + mid * 0.3f, 12f + ph * 0.5f - mid * 0.3f, mid * 0.6f, mid * 0.6f), new Color(1f, 0.7f, 0.1f));
            Label(new Rect(cx, 12f, pw - 16f, ph), coins.ToString(), TextAnchor.MiddleRight, (int)(mid * 1.3f), Gold);

            // power-up / shield indicators
            float iy = 12f + ph + 8f;
            if (magnetT > 0f)
            {
                Label(new Rect(cx, iy, pw, small * 1.6f), "MAGNET", TextAnchor.UpperRight, small, Cyan);
                Bar(new Rect(cx, iy + small * 1.5f, pw, 10f), magnetT / MagnetTime, Cyan);
            }
            if (livesLeft > 0 && state == State.Playing)
            {
                Dot(new Rect(24f, iy + 2f, small * 1.2f, small * 1.2f), Pink);
                Label(new Rect(24f + small * 1.6f, iy, pw, small * 1.6f), "EXTRA LIFE x" + livesLeft, TextAnchor.UpperLeft, small, Pink);
            }

            // time-of-day banner
            if (bannerT > 0f && state == State.Playing)
            {
                float a = Mathf.Clamp01(Mathf.Min(bannerT, (3f - bannerT) * 3f));
                Label(new Rect(0, h * 0.14f, w, mid * 2f), "~ " + bannerText + " ~", TextAnchor.UpperCenter, (int)(mid * 1.4f), new Color(1f, 1f, 1f, a));
            }

            // speed bar + runner tag
            if (state == State.Playing)
            {
                float bw = w * 0.3f;
                Label(new Rect(w * 0.5f - bw * 0.5f, h - 46f - small * 1.4f, bw, small * 1.6f), "SPEED", TextAnchor.UpperCenter, small, Color.white);
                Bar(new Rect(w * 0.5f - bw * 0.5f, h - 40f, bw, 12f), (speed - 10f) / 20f, Color.Lerp(Cyan, Pink, Mathf.Clamp01((speed - 10f) / 20f)));
                Label(new Rect(w - 15f - w * 0.4f, h - small * 2.2f, w * 0.4f, small * 2f), C.name, TextAnchor.LowerRight, small, C.accent);
            }

            Label(new Rect(15, h - mid * 2f, w, mid * 2), "[M] Sound: " + (muted ? "OFF" : "ON"), TextAnchor.LowerLeft, (int)(mid * 0.7f), Color.white);

            if (state == State.Menu) DrawMenu(w, h, big, mid, small, C);
            else if (state == State.Over) DrawOver(w, h, big, mid, small, C);
        }

        void DrawMenu(float w, float h, int big, int mid, int small, CharDef C)
        {
            // title with a cyan offset "glow"
            Label(new Rect(-4f, h * 0.05f + 3f, w, big * 1.5f), "MIAMI SURFERS", TextAnchor.UpperCenter, big, Cyan);
            Label(new Rect(0, h * 0.05f, w, big * 1.5f), "MIAMI SURFERS", TextAnchor.UpperCenter, big, Pink);
            Label(new Rect(0, h * 0.05f + big * 1.25f, w, mid * 2f), "BEACH RUN", TextAnchor.UpperCenter, mid, Color.white);
            Label(new Rect(0, h * 0.05f + big * 1.25f + mid * 1.5f, w, mid * 2f), "Best: " + best, TextAnchor.UpperCenter, small, Gold);

            // runner select panel
            var p = MenuPanel();
            Panel(p, C.accent);
            LayoutMenu();
            Box(prevR, new Color(1f, 1f, 1f, 0.16f));
            Box(nextR, new Color(1f, 1f, 1f, 0.16f));
            Label(prevR, "<", TextAnchor.MiddleCenter, mid, Color.white);
            Label(nextR, ">", TextAnchor.MiddleCenter, mid, Color.white);

            Label(new Rect(p.x, p.y + h * 0.012f, p.width, mid * 2f), C.name, TextAnchor.UpperCenter, (int)(mid * 1.5f), C.accent);
            Label(new Rect(p.x, p.y + h * 0.075f, p.width, mid * 2f), C.perk, TextAnchor.UpperCenter, small + 2, Color.white);

            // page dots
            float ds = mid * 0.5f, gap = ds * 1.7f;
            float dx = w * 0.5f - (Chars.Length * gap) * 0.5f + (gap - ds) * 0.5f;
            float dy = p.y + h * 0.125f;
            for (int i = 0; i < Chars.Length; i++)
            {
                var r = new Rect(dx + i * gap, dy, ds, ds);
                if (i == charIdx) Dot(new Rect(r.x - 3f, r.y - 3f, r.width + 6f, r.height + 6f), Color.white);
                Dot(r, Chars[i].shirt);
            }

            float pulse = 0.7f + 0.3f * Mathf.Sin(Time.time * 4f);
            Label(new Rect(p.x, p.y + h * 0.17f, p.width, mid * 2f), "Tap or press SPACE to start", TextAnchor.UpperCenter, mid, new Color(1f, 1f, 1f, pulse));
            Label(new Rect(p.x, p.y + h * 0.235f, p.width, small * 2f),
                "< > or A/D: pick runner    In game: A/D lane  W jump  S slide  (swipe on mobile)",
                TextAnchor.UpperCenter, (int)(small * 0.85f), new Color(1f, 1f, 1f, 0.85f));
        }

        void DrawOver(float w, float h, int big, int mid, int small, CharDef C)
        {
            // dim the whole scene so the result is impossible to miss
            Box(new Rect(0, 0, w, h), new Color(0f, 0f, 0f, 0.6f * Mathf.Clamp01(overT * 3f)));

            float pw = Mathf.Min(w * 0.92f, h * 1.25f);
            var p = new Rect(w * 0.5f - pw * 0.5f, h * 0.12f, pw, h * 0.6f);
            Box(p, new Color(0.06f, 0.03f, 0.12f, 0.92f));
            Box(new Rect(p.x, p.y, p.width, 6f), new Color(1f, 0.3f, 0.3f));
            Box(new Rect(p.x, p.yMax - 6f, p.width, 6f), new Color(1f, 0.3f, 0.3f));

            Label(new Rect(p.x, p.y + h * 0.025f, p.width, big * 1.6f), "GAME OVER", TextAnchor.UpperCenter, (int)(big * 1.25f), new Color(1f, 0.3f, 0.3f));
            Label(new Rect(p.x, p.y + h * 0.16f, p.width, mid * 2f), "SCORE  " + Mathf.FloorToInt(score), TextAnchor.UpperCenter, (int)(mid * 1.4f), Color.white);
            Label(new Rect(p.x, p.y + h * 0.23f, p.width, mid * 2f), "COINS  " + coins, TextAnchor.UpperCenter, mid, Gold);
            if (newBest)
            {
                float pulse = 0.75f + 0.25f * Mathf.Sin(Time.time * 6f);
                Label(new Rect(p.x, p.y + h * 0.29f, p.width, mid * 2f), "NEW BEST!", TextAnchor.UpperCenter, (int)(mid * 1.2f), new Color(1f, 0.9f, 0.2f, pulse));
            }
            else
            {
                Label(new Rect(p.x, p.y + h * 0.29f, p.width, mid * 2f), "BEST  " + best, TextAnchor.UpperCenter, mid, Gold);
            }
            Label(new Rect(p.x, p.y + h * 0.36f, p.width, mid * 2f), "Runner: " + C.name, TextAnchor.UpperCenter, mid, C.accent);
            Label(new Rect(p.x, p.y + h * 0.42f, p.width, small * 2f), "< > or A/D to switch runner", TextAnchor.UpperCenter, small, new Color(1f, 1f, 1f, 0.85f));

            if (overT >= 0.5f)
            {
                float a = 0.7f + 0.3f * Mathf.Sin(Time.time * 4f);
                Label(new Rect(p.x, p.y + h * 0.49f, p.width, mid * 2f), "Tap or press SPACE to play again", TextAnchor.UpperCenter, mid, new Color(1f, 1f, 1f, a));
            }
        }
    }
}
