MIAMI SURFERS - complete Unity project (v2: more characters + aesthetics)

Unity Hub > Add > "Add project from disk" > select this MiniSurfersProject folder.
Made for Unity 6000.6.0f1 (Unity 6).
Open Assets/Scenes/Main.unity, click the Game view once, press Play.

CONTROLS
  Menu : Left/Right or A/D (or tap the < > buttons / swipe sideways / keys 1-6) = pick runner
         Space / tap = start
  Game : A/D or Left/Right = lane, W/Up/Space = jump, S/Down = slide, M = mute. Mobile: swipe.

NEW IN THIS VERSION
  6 playable runners, each with a perk (choice is saved):
    KAI (balanced) | LUNA (jumps higher) | RICO (fast lane swaps)
    MIKA (+5 pts per coin) | CAPTAIN SAL (survives one crash) | ZARA (gentler speed ramp)
  Living beach crowd: sunbathers, beach volleyball, a surfer, strollers, roller-skaters,
    a waving ice-cream vendor, lifeguard tower, sandcastle.
  New obstacle: fast rolling beach balls (change lanes!). Humans never block the lanes.
  New pickup: Magnet - pulls coins to you for 8 seconds.
  Day/night cycle: sunset > dusk > midnight (moon, stars, glowing windows + lamps) > sunrise > day.
  Extras: clouds, seagulls, animated waves, neon signs, particles (dust, sparkles, confetti,
    speed streaks), blob shadow, camera shake, FOV speed effect, character showcase menu, new HUD.

CODE LAYOUT (Assets/Scripts, one partial class)
  SurferGame.cs            core loop, input, obstacles, camera
  SurferGame.Characters.cs roster (edit the Chars array to add/tweak runners) + human builder
  SurferGame.World.cs      street, crowd, sky cycle (edit the Sky* arrays)
  SurferGame.Fx.cs         particles + shadow
  SurferGame.Hud.cs        HUD and menus

SOUND
Sounds live in Assets/Resources/Sounds (jump, land, slide, lane, coin, crash, start, gameover, music).
They load automatically from code - nothing to assign. To swap a sound, replace the .wav with one of the same name.
